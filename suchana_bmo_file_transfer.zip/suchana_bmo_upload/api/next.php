<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
$cfg=require dirname(__DIR__).'/server-config.php'; $provided=$_SERVER['HTTP_X_BMO_TOKEN']??'';
if(!is_string($provided)||!hash_equals($cfg['api_token'],$provided)){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'Unauthorized']);exit;}
if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);echo json_encode(['ok'=>false,'error'=>'GET only']);exit;}
$qf=dirname(__DIR__).'/data/queue.json'; $fp=fopen($qf,'c+');
if(!$fp){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Queue unavailable']);exit;}
flock($fp,LOCK_EX); $q=json_decode(stream_get_contents($fp)?:'[]',true); if(!is_array($q))$q=[]; $idx=null;
foreach($q as $i=>$entry){if(($entry['status']??'')==='pending'){$idx=$i;break;}}
if($idx===null){flock($fp,LOCK_UN);fclose($fp);echo json_encode(['ok'=>true,'item'=>null]);exit;}
$item=$q[$idx];$q[$idx]['status']='claimed';$q[$idx]['claimed']=time();
rewind($fp);ftruncate($fp,0);fwrite($fp,json_encode($q,JSON_PRETTY_PRINT));fflush($fp);flock($fp,LOCK_UN);fclose($fp);
$item['url']=rtrim($cfg['public_base_url'],'/').'/uploads/bmo/'.rawurlencode($item['filename']);echo json_encode(['ok'=>true,'item'=>$item],JSON_UNESCAPED_SLASHES);
?>